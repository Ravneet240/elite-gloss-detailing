# Elite Gloss Detailing website

A mobile-friendly, free-to-host static website for Elite Gloss Detailing. Includes services, pricing, customer reviews, SEO metadata, and SMS quote-request form.

## Publish on GitHub Pages (phone or desktop)
1. Sign in to GitHub and make a **public** repository named `elite-gloss-detailing`.
2. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder **to the repository root**, preserving filenames. On mobile, use the browser's Desktop Site mode if the upload controls are hidden.
3. In repository **Settings → Pages**, choose **Deploy from a branch**, branch **main**, folder **/(root)**, then Save.
4. Your preview site should appear at `https://YOUR-USERNAME.github.io/elite-gloss-detailing/` after GitHub completes publishing.
5. Do **not** cancel Webador until your new website is ready and your domain has been transferred/connected.

## Custom domain after transferring away from Webador
GitHub repository **Settings → Pages → Custom domain**: `eliteglossdetailing.com`.
At your domain registrar, create these A records for `@`:
- `185.199.108.153`
- `185.199.109.153`
- `185.199.110.153`
- `185.199.111.153`
Optionally add `www` CNAME to `YOUR-USERNAME.github.io` (replace username with actual GitHub account username). Enable Enforce HTTPS after certificate issuance.

## Important checks before publishing
- The old main pricing page lists $79 for exterior detailing of trucks/3-row SUVs/vans, but the old exterior detail page lists $89. This website currently uses $79; **confirm the correct price**.
- The old site contains Google review excerpts. Confirm permission/accuracy and current review count before publishing. No dynamic review count is shown here.
- Replace stylized car illustration / graphics with your actual detailing photographs if you want a closer visual match to your original Webador site.
- The quote form intentionally does not store submissions or send SMS automatically. It opens the visitor's SMS app with a prefilled message to `437-838-0840`. The visitor must tap Send. On certain desktop browsers, SMS links may not work; the displayed phone number remains available.
- This is a freshly coded recreation of the public site content, not a byte-for-byte export of your Webador template or images.
- The Google Fonts stylesheet is loaded from the Internet; fallback fonts are provided.
