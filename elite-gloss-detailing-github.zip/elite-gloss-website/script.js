const menuButton=document.getElementById('menu-toggle');
const nav=document.getElementById('navlinks');
menuButton.addEventListener('click',()=>{const isOpen=nav.classList.toggle('open');menuButton.setAttribute('aria-expanded',String(isOpen));});
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuButton.setAttribute('aria-expanded','false');}));
document.querySelectorAll('[data-service]').forEach(a=>a.addEventListener('click',()=>{document.getElementById('service').value=a.dataset.service;}));
document.getElementById('year').textContent=new Date().getFullYear();
document.getElementById('quote-form').addEventListener('submit',event=>{
 event.preventDefault();const form=event.currentTarget;if(!form.reportValidity())return;
 const d=new FormData(form);const fields=[['Name','name'],['Phone','phone'],['Vehicle','vehicle'],['Vehicle type','type'],['Service','service'],['Preferred day','day'],['Preferred time','time'],['City','city'],['Details','details']];
 const message='Hi Elite Gloss Detailing! I would like a quote.\n\n'+fields.map(([label,key])=>label+': '+(d.get(key)||'Not specified')).join('\n');
 const link=document.createElement('a');link.href='sms:+14378380840?body='+encodeURIComponent(message);document.body.appendChild(link);link.click();link.remove();
 document.getElementById('form-feedback').textContent='Your texting app should open with your request. Please press Send there. If nothing opens, call 437-838-0840.';
});
